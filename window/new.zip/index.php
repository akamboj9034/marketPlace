<!DOCTYPE html>
<head>
<title>Amit Kamboj</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Amit kamboj is a Front End Developer.Pursuing B.Tech in Computer Science (3rd year) from JMIETI,Radaur">
    <meta name="author" content="amit kamboj">

	
 <link rel="icon" type="image/png" href="images/fevicon.png"/>
 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">


  

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>

  

    <!-- Custom Fonts -->

<link href='http://fonts.googleapis.com/css?family=Comfortaa' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Muli' rel='stylesheet' type='text/css'>
 <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
 
 <!-- nice scroll -->
 <script src="nice/jquery.nicescroll.min.js"></script>



<meta name="viewport" content="user-scalable=no" />

  <!-- Custom CSS -->
 <link rel="stylesheet" type="text/css" href="css/stylo.css">
 <link href="css/animate.css" rel="stylesheet" type="text/css">

 <!--plugins-->


  <script src="js/jquery.classyloader.min.js"></script>
 <style>
 
 body
{
background-image:url("images/6.jpg");
margin:0px;
padding:0px;
background-repeat:no-repeat;
 background-attachment: fixed;

height:100%;
width:100%;
background-size:120% 100%;
letter-spacing:0.1em;
font-family: 'Muli', sans-serif;
overflow-Y:hidden;
color:lightgrey;
}
 </style>
<script>
  	
 $(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");
	});
</script>
</head>
<body>

<div class="se-pre-con"></div>


<div class="container">

<div class="header">
<div class="row">


<div class="col-md-7 col-md-push-5">

	<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="fa fa-ellipsis-v"></span>                     
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
    <li class="select">   <a href="#" onclick="home()" style="color:lightgrey;" class="homebtn">HOME</a></li><div class="nextline"><br/></div>
        
      <li> <a href="#" onclick="resume()" style="color:lightgrey;"  class="resumebtn">RESUME</a></li><div class="nextline"><br/></div>
<li><a href="#" onclick="projects()" style="color:lightgrey;"  class="projectbtn">PROJECTS</a></li><div class="nextline"><br/></div>
<li><a href="#" onclick="contact()" style="color:lightgrey;"  class="contactbtn">CONTACT</a></li><div class="nextline"><br/></div>
      </ul>
     
    </div>
  </div>
</nav>
 

</div>

<div class="col-md-5 col-md-pull-7">
<div class="name" >
<a href="#"onclick="home()" >
<h1>Amit Kamboj</h1>
<h5 class="description">web designer and developer</h5>
</a>
</div>
</div>


</div>
</div>






<div class="plates animated fadeInRight">


<div class="row">
<div class="col-md-6"><!--1st level-->






<div class="row">
<div class="col-xs-6">

<div class="folder folder6">

<img class="dp" src="images/dp2.jpg" width="100%">



</div>
</div>

<div class="col-xs-6">

<div class="folder folder7" onclick="slido1()">

<span class="fa fa-pencil-square-o"></span>

<p>resume</p>


</div>
</div>


</div>













<div class="row">

<div class="col-md-4 col-xs-6"><!--2nd level-->

<div class="folder folder1" onclick="slido2()">
<span class="fa fa-image"></span>
<p>photos</p>
</div>


</div>

<div class="col-md-4 col-xs-6"><!--2nd level-->

<div class="folder folder8" onclick="slido3()">

<span class="fa fa-trophy"></span>
<p>projects</p>

</div>
</div>




<div class="col-md-4 col-xs-12"><!--2nd level-->

<div class="row">

<div class="col-md-4 col-xs-6"><!--3rd level-->
<center>
<a style="text-decoration:none;" href="https://www.facebook.com/?q=#/amit.kamboj.7583" target="blank">
<div class="folder folder2">
<span class="fa fa-facebook"></span>

</div>
</a>
</center>
</div>
<div class="col-md-1 col-xs-0">

</div>
<div class="col-md-4 col-xs-6"><!--3rd level-->
<center>
<a style="text-decoration:none;" href="https://twitter.com/amitkamboj9034" target="blank">
<div class="folder folder3">
<span class="fa fa-twitter"></span>

</div>
</a>
</center>
</div>
<div class="col-md-3 col-xs-0">

</div>

</div>


<br/>
<div class="row">

<div class="col-md-4 col-xs-6"><!--3rd level-->
<center>
<a style="text-decoration:none;" href="https://instagram.com/_ammy_kamboj_/" target="blank">
<div class=" folder4">
<span class="fa fa-instagram"></span>

</div>
</a>
</center>
</div>
<div class="col-md-1 col-xs-0">

</div>
<div class="col-md-4 col-xs-6"><!--3rd level-->
<center>
<a style="text-decoration:none;" href="https://www.facebook.com/?q=#/amit.kamboj.7583" target="blank">
<div class="folder5">
<span class="fa fa-linkedin"></span>

</div>
</a>
</center>
</div>
<div class="col-md-3 col-xs-0">

</div>

</div>

</div>


</div>


<!--2nd row-->


</div><!--main coloumn-->


<div class="col-md-6"><!--1st level-->




<div class="row">
<div class="col-xs-6">
<a style="text-decoration:none;" href="mailto:akamboj88@yahoo.com">
<div class="folder folder9">
<span class="fa fa-envelope"></span>
<p>Mail</p>
</div>
</a>
</div>
<div class="col-xs-6">

<div class="folder folder10"  onclick="slido4()">
<span class="fa fa-phone"></span>
<p>Contact</p>
</div>


</div>



</div>




<div class="row">
<div class="col-sm-4 col-xs-6">

<div class="folder folder11"  onclick="slido5()">
<span class="fa fa-rocket"></span>
<p>recent activities</p>
</div>
</div>
<div class="col-sm-4 col-xs-6">

<div class="folder folder12"  onclick="slido6()">
<span class="fa fa-graduation-cap" ></span>
<p>skills</p>
</div>
</div>
<div class="col-sm-4 col-xs-6">

<div class="folder folder13" onclick="slido7()">
<span class="fa fa-gear"></span>
<p>edit</p>
</div>
</div>


</div>


</div><!--main coloumn-->



</div>
</div>
</div><!--container-->









<div class="resume">

   <!-- About Section -->
  
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="difffont">Resume</h2>
                </div>
            </div>
			<br/>
			<br/>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="timeline">
                        <li>
                            <div class="timeline-image">
                             <h4>professional info</h4>
                            </div>
                            <div class="timeline-panel">
                               
                                <div class="timeline-body">
                                  <div class="pro">
 <ul>

   <li>Strong HTML and CSS skills.</li>	<br/>


      <li>Good knowledge Of  jQuery, Javascript, PHP and Ajax.</li>		<br/>
      <li>
Result oriented, selft driven, highly motivated, smart .</li>		<br/>
		
		
		
	</ul>





</div>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                               <h4>work experience</h4>
                            </div>
                            <div class="timeline-panel">
                              
                                <div class="timeline-body">
                                   <div class="pro">

 <ul>
 

		<li>Designed an educational website instideal.com </li>	<br/>
  <li>worked with a startup company sellzie.com and designed its website.</li>		<br/>
   <li>Designed college annual fest website.</li>	<br/>


		
		
		
	</ul>





</div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-image">
                               <h4>education <br/>info</h4>
                            </div>
                            <div class="timeline-panel">
                                
                                <div class="timeline-body">
                                  <div class="pro">

 <ul>
		
	<li>Pursuing B.Tech in Computer Science (3rd year) from JMIETI,Radaur</li>	<br/>

   <li>10+2 (2013) from CBSE board with 70.20% marks</li>	<br/>


      <li>High School  from CBSE board with 79.20% marks</li>	
		
		
		
	</ul>




</div>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                           <br/>  <h4>skills</h4>
                            </div>
							  <div class="timeline-panel">
							 <div class="timeline-body"><br/><br/>
							 <ul>
<li>Photoshop</li>
<li>Bootstrap</li>
<li>Illustrator</li>


</ul>

							 </div>
							 </div>
                        </li>
						
						
						
						  </li>
                        <li>
                            <div class="timeline-image"><br/>
                             <h4>languages</h4>
                            </div>
							  <div class="timeline-panel">
							 <div class="timeline-body"><br/><br/>
						<ul>
<li>HTML5/CSS3</li>
<li>Javascript</li>
<li>PHP</li>
<li>Ajax</li>
<li>jQuery</li>


</ul>


							 </div>
							 </div>
                        </li>
						
						
						
						
						
                    </ul>
                </div>
            </div>
        </div>
   



</div>



<div class="container">
<div class="contact">

<br/>
<br/>
<div class="row">
<div class="col-md-6">

<h1 id="contactheading" class="difffont">Drop me a line</h1>
<h4 class="difffont">I would love to hear to from you.</h4>
<br/>
<hr/>
<br/>
<br/>


<div class="contactsocial">


<a href="https://www.facebook.com/amit.kamboj.7583"><span class="fa fa-facebook-f smcircle"></span></a>
<a href="https://twitter.com/amitkamboj9034"><span class="fa fa-twitter smcircle"></span></a>
<a href="#"><span class="fa fa-google-plus smcircle"></span></a>

</div>
<br/>
<br/>
<p><b>Cell</b> &nbsp 8950669997</p>
<p><b>Email</b> &nbsp akamboj88@yahoo.com</p>



</div>


<div class="col-md-6 down" >

<p>Looking forward to answering your email</p>
<br/>
  
	<div class="contactform">

	 <div class="form-group row">
					<div class="col-md-2">
					</div>
					<div class="col-md-9">
                        <input type="text"  class="form-control input-lg" placeholder="Name" value=""/>
                    </div>
					<div class="col-md-1">
					</div>
      </div>
					
	
	
	 <div class="form-group row">
					<div class="col-md-2">
					</div>
					<div class="col-md-9">
                        <input type="text" class="form-control input-lg" placeholder="E-mail" value=""/>
                    </div>
					<div class="col-md-1">
					</div>
                    </div>
						
	 <div class="form-group row">
					<div class="col-md-2">
					</div>
					<div class="col-md-9">
                       <textarea class="form-control input-lg" rows="6" placeholder="Message"></textarea>
                </div>
					<div class="col-md-1">
					</div>
				
                    </div>
						
	
	
		 <div class="form-group row">
					<div class="col-md-2">
					</div>
					<div class="col-md-9">
							<input type="submit" name="send" id="submit">
                    </div>
					<div class="col-md-1">
					</div>
                    </div>
	
	
	
	
	
	</div>
	
	
	
</div>


</div>
<br/>
<br/>
</div>
</div>







<div class="container">
<div class="edit">

<h1 class="difffont">Please login to continue</h1><br/><br/>
<div class="contactform">

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" >
	 <div class="form-group row">
					<div class="col-md-4">
					<center>
					<label>Username:</label></center>
					</div>
					<div class="col-md-4">
                        <input type="text"  class="form-control input-lg" name="username" placeholder="Username" value=""/>
                    </div>
					<div class="col-md-4">
					</div>
      </div>
					
	
		 <div class="form-group row">
					<div class="col-md-4"><center>
					<label>Password:</label></center>
					</div>
					<div class="col-md-4">
                        <input type="password"  class="form-control input-lg" placeholder="password" name="password" value=""/>
                    </div>
					<div class="col-md-4">
					</div>
      </div>
	  <div id="err">
	  
	  
	  </div>
						 <div class="form-group row">
					<div class="col-md-4">
					</div>
					<div class="col-md-4">
							<input type="submit" name="submit" id="submit">
                    </div>
					<div class="col-md-4">
					</div>
                    </div>
	
						
</form>
</div>
</div>
</div>



<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$un=$_POST['username'];
$pass=$_POST['password'];

include "connect.php";
$sql="Select * from login WHERE username='$un' and password='$pass'";
$result=mysql_query($sql);
$count=mysql_num_rows($result);
if($count==1){
session_start();

		$_SESSION['user']=$un;


echo"<script>window.location='admin.php'; </script>";


}
else{
		echo"<script> document.getElementById('err').innerHTML=' wrong username or password';
		$('#err').addClass('fa-times-circle');
		
		</script>";

}
}
?>





<div id="gallery">





</div>





<div class="container">
<div class="skills">
<h1>Skills</h1>
<br/>
<br/>
<div class="row">
<div class="col-md-2 col-xs-4">
<div class="html">  
<center>
    <canvas class="loader1"></canvas>
    <h4>HTML5/CSS3</h4>  
</center>            
</div>
</div>
<div class="col-md-2 col-xs-4">
<div class="php">  
<center>
    <canvas class="loader2"></canvas>
    <h4>PHP</h4>  
</center>            
</div>
</div>

<div class="col-md-2 col-xs-4">
<div class="bootstrap">  
<center>
    <canvas class="loader3"></canvas>
    <h4>Bootstrap</h4>  
</center>            
</div>
</div>
<div class="col-md-2 col-xs-4">
<div class="jquery">  
<center>
    <canvas class="loader4"></canvas>
    <h4>jQuery</h4>  
</center>            
</div>
</div>

<div class="col-md-2 col-xs-4">
<div class="ajax">  
<center>
    <canvas class="loader5"></canvas>
    <h4>Ajax</h4>  
</center>            
</div>
</div>

<div class="col-md-2 col-xs-4">
<div class="photoshop">  
<center>
    <canvas class="loader6"></canvas>
    <h4>Photoshop</h4>  
</center>            
</div>
</div>


</div>
</div>
</div>

<div class="container">
<div class="activities">
<h1>Recent Activites</h1>
<br/>
<h3 style="margin-left:40px;">2015</h3>
<div class="activity">
<div class="row">
<div class="col-md-2">
</div>

<div class="col-md-2">
<div class="date">
<p>21/09</p>
</div>
</div>
<div class="col-md-6">
<div class="post">
<h5>Just got the Internshala Student Partner title</h5>
</div>
</div>

<div class="col-md-2">
</div>
</div>
</div>
<div class="activity">
<div class="row">
<div class="col-md-2">
</div>

<div class="col-md-2">
<div class="date">
<p>13/09</p>
</div>
</div>
<div class="col-md-6">
<div class="post">
<h5>Guess what, delivered a seminar on Google Glass.Wasn't that bad</h5>
</div>
</div>

<div class="col-md-2">
</div>
</div>
</div>


</div>
</div>






<div class="container">

<div class="projects">
<div class="project">
<p id="contactheading">RECENT PROJECTS</p>

<br/>

<div class="row">
<div class="col-md-6">
<center>
<img src="images/p1.jpg" height="250px" width="80%">
</center>
</div>
<div class="col-md-6">
<div class="projectno" >
<p>project | 01</p>

</div>

<hr/>

<h3>Gyaanshala</h3>
<br/>

<p class="projectdetails">
A social platform to share knowledge.</p>
<div id="demobtn">
<a href="http://www.gyaanshala.comli.com" target="blank" id="demo">
<div class="demo">
GET A DEMO
</div>

</a>
</div>
</div>
</div>
</div>



<div class="project">
<div class="row">
<div class="col-md-6">
<center>
<img src="images/p2.jpg" height="250px" width="80%">
</center>
</div>
<div class="col-md-6">
<div class="projectno" >
<p>project | 02</p>

</div>

<hr/>

<h3>Shopox</h3>
<br/>

<p class="projectdetails">

An E-commerce website which allows users to shop from nearby shops.</p>
<div id="demobtn">
<a href="http://shopox.comli.com" target="blank" id="demo">
<div class="demo">
GET A DEMO
</div>

</a>
</div>
</div>
</div>
</div>



<div class="project">
<div class="row">
<div class="col-md-6">
<center>
<img src="images/p3.jpg" height="250px" width="80%">
</center>
</div>
<div class="col-md-6">
<div class="projectno" >
<p>project | 03</p>

</div>

<hr/>

<h3>Blood donation management system</h3>
<br/>

<p class="projectdetails">
A blood donation management system to keep track of donators.</p>
<div id="demobtn">
<a href="http://jmieti.org/zestival/zestival.html" target="blank" id="demo">
<div class="demo">
GET A DEMO
</div>

</a>
</div>
</div>
</div>
</div>

<hr/>

<div class="row">
<div class="col-xs-8">
<p style="letter-spacing:0.3em;margin-top:30px;">Just a sample of my work. To see more or discuss possible work</p>
</div>
<div class="col-xs-4">
<a href="#" style="text-decoration:none;color:white;" onclick="contact()">
<div class="talk">lets talk</div>
</a>  

</div>
</div>

</div>

</div>





<!--sccipts-->
  <script src="js/scripts.js"></script>

  <script src="js/bootstrap.min.js"></script>

   <script type="text/javascript" src="js/jquery.countTo.js"></script>



</body>
</html>