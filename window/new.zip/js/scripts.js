


  $(document).ready(function() {
  
	var nice = $("html").niceScroll();  // The document page (body)
	
	$("#div1").html($("#div1").html()+' '+nice.version);
    
    $("#boxscroll").niceScroll({cursorborder:"",cursorcolor:"#00F",boxzoom:true}); // First scrollable DIV

    $("#boxscroll2").niceScroll("#contentscroll2",{cursorcolor:"#F00",cursoropacitymax:0.7,boxzoom:true,touchbehavior:true});  // Second scrollable DIV
    $("#boxframe").niceScroll("#boxscroll3",{cursorcolor:"#0F0",cursoropacitymax:0.7,boxzoom:true,touchbehavior:true});  // This is an IFrame (iPad compatible)
	
    $("#boxscroll4").niceScroll("#boxscroll4 .wrapper",{boxzoom:true});  // hw acceleration enabled when using wrapper
    
  });
function resume(){

  $("body").animate({scrollTop: 0},"slow");
    

 $(".activities").delay(100).hide("fade",300);
    $(".plates").removeClass("fadeInRight");
  $(".edit").delay(100).hide("fade",300);
 $(".contact").delay(100).hide("fade",300);
 $(".projects").delay(100).hide("fade",300);
 $("#skills").delay(100).hide("fade",300);
 $(".skills").delay(100).hide("fade",300);
  $("#gallery").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
 $(".resume").delay(300).show("fade",300);
    $(".resume").addClass("animated");
    $(".resume").addClass("fadeInRight");
}
function contact(){
$("body").animate({scrollTop: 0},"slow");
     $(".projects").delay(100).hide("fade",300);
 $(".activities").delay(100).hide("fade",300);
 $(".edit").delay(100).hide("fade",300);
 $(".resume").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
$(".contact").delay(300).show("fade",300);
 $(".skills").delay(100).hide("fade",300);
  $("#gallery").delay(100).hide("fade",300);
    $(".plates").removeClass("fadeInRight");

     $(".contact").addClass("animated");
    $(".contact").addClass("fadeInRight");
}

function projects(){
$("body").animate({scrollTop: 0},"slow");
     $(".contact").delay(100).hide("fade",300);
 $(".activities").delay(100).hide("fade",300);
 $(".edit").delay(100).hide("fade",300);
 $(".resume").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
$(".projects").delay(300).show("fade",300);
 $(".skills").delay(100).hide("fade",300);
  $("#gallery").delay(100).hide("fade",300);
    $(".plates").removeClass("fadeInRight");

     $(".projects").addClass("animated");
    $(".projects").addClass("fadeInRight");
}



	
 $(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");
	});
	
	
	
function slido1(){
 

  $("body").animate({scrollTop: 0},"slow");
    


 $(".projects").delay(100).hide("fade",300);
    $(".plates").removeClass("fadeInRight");
    $(".folder7").addClass("animated");
    $(".folder7").addClass("flip");
 $(".activities").delay(100).hide("fade",300);
 $(".edit").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
 $(".skills").delay(100).hide("fade",300);
  $("#gallery").delay(100).hide("fade",300);
 $(".contact").delay(100).hide("fade",300);
 $(".resume").delay(300).show("fade",300);
    $(".resume").addClass("animated");
    $(".resume").addClass("fadeInRight");
}
function slido2(){
 
  $("body").animate({scrollTop: 0},"slow");
    

 $(".projects").delay(100).hide("fade",300);
$(".plates").removeClass("fadeInRight");
    $(".folder1").addClass("animated");
    $(".folder1").addClass("flip");
 $(".activities").delay(100).hide("fade",300);
 $(".edit").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
 $(".contact").delay(100).hide("fade",300);
 $(".resume").delay(100).hide("fade",300);
 $("#gallery").delay(300).show("fade",300);
    $("#gallery").addClass("animated");
    $("#gallery").addClass("fadeInRight");
 
loadXMLDoc();
 
 
 

}
function slido3(){
 

  $("body").animate({scrollTop: 0},"slow");
    



$(".plates").removeClass("fadeInRight");
    $(".folder8").addClass("animated");
    $(".folder8").addClass("flip");
 $(".activities").delay(100).hide("fade",300);
 $(".edit").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
 $(".contact").delay(100).hide("fade",300);
 $(".resume").delay(100).hide("fade",300);
 $("#gallery").delay(100).hide("fade",300);
 $(".projects").delay(300).show("fade",300);
    $(".projects").addClass("animated");
    $(".projects").addClass("fadeInRight");
}
function slido4(){
 
 $(".projects").delay(100).hide("fade",300);
  $("body").animate({scrollTop: 0},"slow");
     $(".activities").delay(100).hide("fade",300);
 $(".skills").delay(100).hide("fade",300);
  $("#gallery").delay(100).hide("fade",300);
 $(".edit").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
$(".contact").delay(300).show("fade",300);
    $(".plates").removeClass("fadeInRight");
    $(".folder10").addClass("animated");
    $(".folder10").addClass("flip");

 
     $(".contact").addClass("animated");
    $(".contact").addClass("fadeInRight");
}
function slido5(){
 

  $("body").animate({scrollTop: 0},"slow");
    
 $(".projects").delay(100).hide("fade",300);
 $(".skills").delay(100).hide("fade",300);
  $("#gallery").delay(100).hide("fade",300);
 $(".edit").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
 $(".contact").delay(100).hide("fade",300);
$(".activities").delay(300).show("fade",300);
    $(".plates").removeClass("fadeInRight");
    $(".folder11").addClass("animated");
    $(".folder11").addClass("flip");

 
     $(".activities").addClass("animated");
    $(".activities").addClass("fadeInRight");
}
function slido6(){
 

  $("body").animate({scrollTop: 0},"slow");
    


 $(".projects").delay(100).hide("fade",300);
    $(".plates").removeClass("fadeInRight");
    $(".folder12").addClass("animated");
    $(".folder12").addClass("flip");
 $(".activities").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
 $("#gallery").delay(100).hide("fade",300);
 $(".contact").delay(100).hide("fade",300);
 $(".resume").delay(100).hide("fade",300);
 $(".skills").show("fade",300);
   
     $(".skills").addClass("animated");
    $(".skills").addClass("fadeInRight");
	


	 
	      $('.loader1').ClassyLoader({
		                                        height:'100px',
												width:'100px',
                                                percentage: 100,
                                                speed: 10,
												animate:true,
												start:'top',
												roundedLine:true,
                                                fontSize: '15px',
												fontColor:'lightgrey',
                                                diameter: 40,
                                                lineColor: '#A14053',
                                                remainingLineColor: 'transparent',
                                                lineWidth: 6,
												
                                            });
	 
	 
	 
	 
	      $('.loader2').ClassyLoader({
		                                        height:'100px',
												width:'100px',
                                                percentage: 95,
                                                speed: 10,
												animate:true,
												start:'top',
												roundedLine:true,
                                                fontSize: '15px',
												fontColor:'lightgrey',
                                                diameter: 40,
                                                lineColor: '#1F6161',
                                                remainingLineColor: 'transparent',
                                                lineWidth: 6,
												
                                            });
	 
	      $('.loader3').ClassyLoader({
		                                        height:'100px',
												width:'100px',
                                                percentage: 100,
                                                speed: 10,
												animate:true,
												start:'top',
												roundedLine:true,
                                                fontSize: '15px',
												fontColor:'lightgrey',
                                                diameter: 40,
                                                lineColor: '#50BB7F',
                                                remainingLineColor: 'transparent',
                                                lineWidth: 6,
												
                                            });
	 
	      $('.loader4').ClassyLoader({
		                                        height:'100px',
												width:'100px',
                                                percentage: 100,
                                                speed: 10,
												animate:true,
												start:'top',
												roundedLine:true,
                                                fontSize: '15px',
												fontColor:'lightgrey',
                                                diameter: 40,
                                                lineColor: '#D9512B',
                                                remainingLineColor: 'transparent',
                                                lineWidth: 6,
												
                                            });
	 
	      $('.loader5').ClassyLoader({
		                                        height:'100px',
												width:'100px',
                                                percentage: 90,
                                                speed: 10,
												animate:true,
												start:'top',
												roundedLine:true,
                                                fontSize: '15px',
												fontColor:'lightgrey',
                                                diameter: 40,
                                                lineColor: '#00C0F2',
                                                remainingLineColor: 'transparent',
                                                lineWidth: 6,
												
                                            });
	 
	      $('.loader6').ClassyLoader({
		                                        height:'100px',
												width:'100px',
                                                percentage: 100,
                                                speed: 10,
												animate:true,
												start:'top',
												roundedLine:true,
                                                fontSize: '15px',
												fontColor:'lightgrey',
                                                diameter: 40,
                                                lineColor: '#094DB5',
                                                remainingLineColor: 'transparent',
                                                lineWidth: 6,
												
                                            });
	 
	 
	 
	 
	 
	 
	 
	 
	 }
function slido7(){
 

  $("body").animate({scrollTop: 0},"slow");
    
 $(".projects").delay(100).hide("fade",300);
 $(".activities").delay(100).hide("fade",300);
    $(".plates").removeClass("fadeInRight");
    $(".folder13").addClass("animated");
    $(".folder13").addClass("flip");
 $(".skills").delay(100).hide("fade",300);
  $("#gallery").delay(100).hide("fade",300);
 $(".plates").delay(100).hide("fade",300);
 $(".contact").delay(100).hide("fade",300);
 $(".resume").delay(300).hide("fade",300);
 $(".edit").delay(300).show("fade",300);
    $(".edit").addClass("animated");
    $(".edit").addClass("fadeInRight");


}

function home(){
 $("body").animate({scrollTop: 0},"slow");
    

 $(".projects").delay(100).hide("fade",300);
 $(".skills").delay(100).hide("fade",300);
  $(".activities").delay(100).hide("fade",300);
  $("#gallery").delay(100).hide("fade",300);
 $(".plates").delay(100).show("fade",300);
    $(".resume").hide("fade",300);
    $(".contact").hide("fade",300);
    $(".edit").hide("fade",300);
    $(".plates").addClass("fadeInRight");
    $(".folder").removeClass("flip");
   
   

}




 $('.se-pre-con').hide().ajaxStart(function(){
    $(this).show();
}).ajaxStop(function() {
    $(this).hide();
});
 
function loadXMLDoc()
{
 $('.se-pre-con').show();
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("gallery").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","photos.html",true);
xmlhttp.send();
 $('.se-pre-con').hide(); 
}

   
 
