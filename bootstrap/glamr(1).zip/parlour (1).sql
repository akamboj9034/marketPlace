-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 26, 2016 at 06:55 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `parlour`
--

-- --------------------------------------------------------

--
-- Table structure for table `bleach`
--

CREATE TABLE IF NOT EXISTS `bleach` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `bleach`
--

INSERT INTO `bleach` (`id`, `type`, `rupees`) VALUES
(1, 'Fruit Bleach', '150'),
(2, 'Oxy Bleach', '200'),
(3, 'Gold Bleach', '150'),
(4, 'Diamond Bleach', '150'),
(5, 'Ozone Bleach', '250'),
(6, 'Full Body Bleach', '600');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(121) NOT NULL AUTO_INCREMENT,
  `email` varchar(121) NOT NULL,
  `type` varchar(121) NOT NULL,
  `pid` int(121) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `email`, `type`, `pid`) VALUES
(6, 'ankit@a.a', 'massage', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cleansing`
--

CREATE TABLE IF NOT EXISTS `cleansing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `cleansing`
--

INSERT INTO `cleansing` (`id`, `type`, `rupees`) VALUES
(1, 'Fruit Cleansing', '400'),
(2, 'Aroma Cleansing', '450'),
(3, 'Anti Acne Cleansing', '450'),
(4, 'Glow Cleansing', '550'),
(5, 'Oxy Cleansing', '600'),
(6, 'Whitening Cleansing', '800');

-- --------------------------------------------------------

--
-- Table structure for table `facial`
--

CREATE TABLE IF NOT EXISTS `facial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `facial`
--

INSERT INTO `facial` (`id`, `type`, `rupees`) VALUES
(1, 'Fruit facial', '600'),
(2, 'Glow Facial', '700'),
(3, 'Anti Tan Facial', '800'),
(4, 'Anti Acne Facial', '900'),
(5, 'Diamond Facial', '800'),
(6, 'Silver Facial', '850'),
(7, 'Gold Facial', '1050'),
(8, 'Ozone Facial', '1150'),
(9, 'Pearl Facial', '800'),
(10, 'Oxy Facial', '900'),
(11, 'De Tan Facial', '1150'),
(12, 'Aroma Facial', '900'),
(13, 'O3+ Facial', '2050'),
(14, 'O3+ Whitening', '1700'),
(15, 'VLCC Facial', '1150');

-- --------------------------------------------------------

--
-- Table structure for table `haircoloring`
--

CREATE TABLE IF NOT EXISTS `haircoloring` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `haircoloring`
--

INSERT INTO `haircoloring` (`id`, `type`, `rupees`) VALUES
(1, 'Root Touch Up', '600'),
(2, 'Polishing', '2400'),
(3, 'Base Color(Loreal)', '3000'),
(4, 'Fashion Shade', '4000');

-- --------------------------------------------------------

--
-- Table structure for table `haircut`
--

CREATE TABLE IF NOT EXISTS `haircut` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(30) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `haircut`
--

INSERT INTO `haircut` (`id`, `type`, `rupees`) VALUES
(1, 'Basic Hair Cut', '250'),
(2, 'Advance Hair Cut', '400'),
(3, 'Hair Dryer Straight', '200'),
(4, 'Hair Dryer Out Curls', '300'),
(5, 'Hair Straightening Temporary', '350'),
(6, 'Advance Straightening', '600');

-- --------------------------------------------------------

--
-- Table structure for table `hairspa`
--

CREATE TABLE IF NOT EXISTS `hairspa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `hairspa`
--

INSERT INTO `hairspa` (`id`, `type`, `rupees`) VALUES
(1, 'Basic Spa', '400'),
(2, 'Matrix Spa', '600'),
(3, 'Loreal Spa', '700'),
(4, 'Booster Spa', '1200');

-- --------------------------------------------------------

--
-- Table structure for table `hairtreatment`
--

CREATE TABLE IF NOT EXISTS `hairtreatment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(35) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `hairtreatment`
--

INSERT INTO `hairtreatment` (`id`, `type`, `rupees`) VALUES
(1, 'Split Ends Treatment', '300'),
(2, 'Candanl Treatment', '400'),
(3, 'Hair Fall Treatment', '900'),
(4, 'Dandruff Treatment', '1200'),
(5, 'Hair Wash', '200'),
(6, 'Hair Wash (With Conditioning)', '300'),
(7, 'Hair Wash (With Deep Conditioning)', '400'),
(8, 'Hair Wash (With Blow Dry)', '300'),
(9, 'Smoothening', '5000'),
(10, 'Moisture Therapy', '5500'),
(11, 'Shine Bond', '6000'),
(12, 'Silk Treat', '6500'),
(13, 'Keratine', '12000');

-- --------------------------------------------------------

--
-- Table structure for table `makeup`
--

CREATE TABLE IF NOT EXISTS `makeup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `makeup`
--

INSERT INTO `makeup` (`id`, `type`, `rupees`) VALUES
(1, 'Saree Draping', '250'),
(2, 'Hair Do', '350'),
(3, 'Reception MAkeup', '1200'),
(4, 'Party Makeup', '1200'),
(5, 'Model Maleup', '1500'),
(6, 'Engagement Makeup', '1800'),
(7, 'Bridal Makeup', '3500');

-- --------------------------------------------------------

--
-- Table structure for table `manicure`
--

CREATE TABLE IF NOT EXISTS `manicure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `manicure`
--

INSERT INTO `manicure` (`id`, `type`, `rupees`) VALUES
(1, 'Manicure', '250'),
(2, 'Pedicure', '300'),
(3, 'Ozone Manicure', '350'),
(4, 'Ocone Pedicure', '400'),
(5, 'De-Tan Manicure', '400'),
(6, 'De-Tan Pedicure', '450'),
(7, 'Nail Filling', '50'),
(8, 'Foot Massage', '200');

-- --------------------------------------------------------

--
-- Table structure for table `massage`
--

CREATE TABLE IF NOT EXISTS `massage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(35) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `massage`
--

INSERT INTO `massage` (`id`, `type`, `rupees`) VALUES
(1, 'Head Massage (Normal)', '250'),
(2, 'Head Massage (With Olive Oil)', '350'),
(3, 'Head Massage (With steam)', '450'),
(4, 'Head Massage (With Neck & Back)', '500'),
(5, 'Body Massage (Normal)', '1150'),
(6, 'Body Massage (With Aroma Oil)', '1400'),
(7, 'Body Spa', '1700'),
(8, 'Body Polishing', '2300');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` char(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `fullname`, `email`, `pass`) VALUES
(1, 'aman', 'am@gmail.com', 'a'),
(2, 'ankit', 'ankit@a.a', 'a');

-- --------------------------------------------------------

--
-- Table structure for table `threading`
--

CREATE TABLE IF NOT EXISTS `threading` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `threading`
--

INSERT INTO `threading` (`id`, `type`, `rupees`) VALUES
(1, 'Eyebrow', '40'),
(2, 'Forehead', '40'),
(3, 'Upper Lips', '40'),
(4, 'Full Face', '100');

-- --------------------------------------------------------

--
-- Table structure for table `waxing`
--

CREATE TABLE IF NOT EXISTS `waxing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(25) NOT NULL,
  `rupees` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `waxing`
--

INSERT INTO `waxing` (`id`, `type`, `rupees`) VALUES
(1, 'Full Arms', '200'),
(2, 'Half Legs', '200'),
(3, 'Full Legs', '350'),
(4, 'Full Front', '250'),
(5, 'Full Back', '300'),
(6, 'Bikini', '600'),
(7, 'Full Face', '150'),
(8, 'Full Body', '1150'),
(9, 'Underarms', '50');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
